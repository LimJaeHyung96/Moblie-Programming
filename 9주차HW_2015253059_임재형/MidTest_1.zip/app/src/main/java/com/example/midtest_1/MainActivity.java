package com.example.midtest_1;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.app.Dialog;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {

    RadioGroup rGroup;
    RadioButton dogBtn, catBtn, rabbitBtn, horseBtn;
    Button showBtn;
    ImageView img;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("중간고사 1번 문제");

        rGroup = (RadioGroup) findViewById(R.id.Rgroup);

        dogBtn = (RadioButton) findViewById(R.id.DogBtn);
        catBtn = (RadioButton) findViewById(R.id.CatBtn);
        rabbitBtn = (RadioButton) findViewById(R.id.RabbitBtn);
        horseBtn = (RadioButton) findViewById(R.id.HorseBtn);

        showBtn = (Button) findViewById(R.id.ShowBtn);

        showBtn.setOnClickListener(new View.OnClickListener() {
            View dialogView = (View) View.inflate(MainActivity.this,R.layout.animal,null);
            AlertDialog.Builder dialog = new AlertDialog.Builder(MainActivity.this);
            ImageView img = (ImageView) dialogView.findViewById(R.id.ImageView);

            @Override
            public void onClick(View v) {
                switch (rGroup.getCheckedRadioButtonId()){
                    case R.id.DogBtn:
                        img.setImageResource(R.drawable.dog);
                        dialog.setTitle("강아지");
                        break;
                    case R.id.CatBtn:
                        img.setImageResource(R.drawable.cat);
                        dialog.setTitle("고양이");
                        break;
                    case R.id.RabbitBtn:
                        img.setImageResource(R.drawable.rabbit);
                        dialog.setTitle("토끼");
                        break;
                    case R.id.HorseBtn:
                        img.setImageResource(R.drawable.horse);
                        dialog.setTitle("말");
                        break;
                    default:
                        Toast.makeText(getApplicationContext(),"동물 먼저 선택하세요",Toast.LENGTH_SHORT).show();
                }
                if(dialogView.getParent() != null)
                    ((ViewGroup) dialogView.getParent()).removeView(dialogView);
                dialog.setView(dialogView);
                dialog.setNegativeButton("닫기",null);
                dialog.show();
            }
        });
    }
}