package com.example.midtest_2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.widget.Button;
import android.widget.Chronometer;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    Chronometer chrono;
    ScrollView scrollView;
    TextView record;
    Button bt_sta, bt_rec;

    private int cnt = 1;
    private String record_text = "";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        chrono = (Chronometer) findViewById(R.id.chronometer1);
        scrollView = (ScrollView) findViewById(R.id.scrollView);
        record = (TextView) findViewById(R.id.record);
        bt_sta = (Button) findViewById(R.id.bt_sta);
        bt_rec = (Button) findViewById(R.id.bt_rec);

        bt_sta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(bt_sta.getText().equals("시작")){
                    bt_sta.setText("종료");
                    chrono.setBase(SystemClock.elapsedRealtime());
                    chrono.start();
                    record_text = "";
                    record.setText(record_text);
                    bt_rec.setEnabled(true);
                    cnt = 0;
                }else if(bt_sta.getText().equals("종료")){
                    bt_sta.setText("시작");
                    chrono.stop();
                    bt_rec.setEnabled(false);
                }
            }
        });

        bt_rec.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                record_text += cnt++ + ". " + chrono.getText() + "\n";
                record.setText(record_text);
            }
        });
    }
}