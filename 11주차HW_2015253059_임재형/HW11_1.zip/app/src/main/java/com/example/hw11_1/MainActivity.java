package com.example.hw11_1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    RadioGroup radioGroup;
    RadioButton intentSecond, intentThird;
    Button btnNewActivity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        radioGroup = (RadioGroup)findViewById(R.id.Rgroup);
        intentSecond = (RadioButton)findViewById(R.id.intentSecond);
        intentThird = (RadioButton)findViewById(R.id.intentThird);

        btnNewActivity = (Button)findViewById(R.id.btnNewActivity);
        btnNewActivity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent2 = new Intent(getApplicationContext(),SecondActivity.class);
                Intent intent3 = new Intent(getApplicationContext(),ThirdActivity.class);

                switch (radioGroup.getCheckedRadioButtonId()){
                    case R.id.intentSecond:
                        startActivity(intent2);
                        break;
                    case R.id.intentThird:
                        startActivity(intent3);
                        break;
                    default:
                        Toast.makeText(getApplicationContext(),"위 버튼을 선택해주세요.",Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}