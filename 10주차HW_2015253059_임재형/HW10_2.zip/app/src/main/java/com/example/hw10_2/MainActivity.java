package com.example.hw10_2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.shapes.OvalShape;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(new MyGraphicView(this));
    }

    private static class MyGraphicView extends View{
        public MyGraphicView(Context context){
            super(context);
        }

        @Override
        protected void onDraw(Canvas canvas){
            super.onDraw(canvas);
            Paint paint = new Paint();
            paint.setAntiAlias(true);
            paint.setColor(Color.BLACK);
            paint.setStrokeWidth(100);

            canvas.drawLine(100,100, 800, 100, paint);

            paint.setStrokeCap(Paint.Cap.ROUND);
            canvas.drawLine(100,250, 800, 250, paint);

            RectF rect1 = new RectF(100, 350, 800, 550);
            canvas.drawOval(rect1, paint);

            RectF rect2 = new RectF(100, 600, 300, 800);
            canvas.drawArc(rect2, 45, 90, true, paint);

            RectF rect3 = new RectF(100, 900, 300, 1100);
            paint.setColor(Color.BLUE);
            canvas.drawRect(rect3, paint);

            RectF rect4 = new RectF(100+60, 900+60, 300+60, 1100+60);
            paint.setColor(Color.argb(120,255,0,0));
            canvas.drawRect(rect4, paint);

        }
    }
}