package com.example.hw5_3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    LinearLayout baseLayout, layout1, layout2, layout3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        baseLayout = (LinearLayout)findViewById(R.id.BaseLayout);
        layout1 = (LinearLayout)findViewById(R.id.Layout1);
        layout2 = (LinearLayout)findViewById(R.id.Layout2);
        layout3 = (LinearLayout)findViewById(R.id.Layout3);

        baseLayout.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Toast.makeText(getApplicationContext(),"이 것은 바탕화면입니다.",Toast.LENGTH_SHORT).show();
            }
        });

        layout1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(),"폭 : 250dp, 높이 : 250dp",Toast.LENGTH_SHORT).show();
            }
        });

        layout2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(),"폭 : 150dp, 높이 : 150dp",Toast.LENGTH_SHORT).show();
            }
        });

        layout3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(),"폭 : 50dp, 높이 : 50dp",Toast.LENGTH_SHORT).show();
            }
        });
    }
}