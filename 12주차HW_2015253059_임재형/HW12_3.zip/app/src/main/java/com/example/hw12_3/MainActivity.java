package com.example.hw12_3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Integer[] posterID = {R.drawable.mov01, R.drawable.mov02, R.drawable.mov03, R.drawable.mov04, R.drawable.mov05,
            R.drawable.mov06, R.drawable.mov07, R.drawable.mov08, R.drawable.mov09, R.drawable.mov10,
            R.drawable.mov11, R.drawable.mov12, R.drawable.mov13, R.drawable.mov14, R.drawable.mov15,
            R.drawable.mov16, R.drawable.mov17, R.drawable.mov18, R.drawable.mov19, R.drawable.mov20,
            R.drawable.mov21, R.drawable.mov22, R.drawable.mov23, R.drawable.mov24, R.drawable.mov25,
            R.drawable.mov26, R.drawable.mov27, R.drawable.mov28, R.drawable.mov29, R.drawable.mov30,
            R.drawable.mov31, R.drawable.mov32, R.drawable.mov33, R.drawable.mov34, R.drawable.mov35,
            R.drawable.mov36, R.drawable.mov37, R.drawable.mov38, R.drawable.mov39, R.drawable.mov40,
            R.drawable.mov41, R.drawable.mov42, R.drawable.mov43, R.drawable.mov44, R.drawable.mov45,
            R.drawable.mov46, R.drawable.mov47, R.drawable.mov48, R.drawable.mov49, R.drawable.mov50,
            R.drawable.mov51, R.drawable.mov52, R.drawable.mov53, R.drawable.mov54, R.drawable.mov55,
            R.drawable.mov56, R.drawable.mov57, R.drawable.mov58, R.drawable.mov59, R.drawable.mov60,
            R.drawable.mov61, R.drawable.mov62, R.drawable.mov63, R.drawable.mov64, R.drawable.mov65,
            R.drawable.mov66, R.drawable.mov67, R.drawable.mov68, R.drawable.mov69, R.drawable.mov70,
            R.drawable.mov71, R.drawable.mov72, R.drawable.mov74, R.drawable.mov75,
            R.drawable.mov76, R.drawable.mov77, R.drawable.mov78, R.drawable.mov79, R.drawable.mov80,
            R.drawable.mov81, R.drawable.mov82, R.drawable.mov83};

    String[] movieName = {"토이스토리4", "호빗 : 다섯 군대 전투", "제이슨 본", "반지의 제왕", "정직한 후보",
            "나쁜 녀석들 포에버", "겨울왕국2", "알라딘", "극한직업", "스파이더맨 : 파 프롬 홈",
            "레옹", "주먹왕 랄프2", "타짜 : 원 아이드 잭", "걸캅스", "도굴",
            "어벤져스 : 엔드게임", "엑시트", "캡틴 마블", "봉오동 전투", "분노의 질주 : 홉스&쇼",
            "아바타", "힘을 내요 미스터 리", "포드v페라리", "쥬만지 : 넥스트 레벨", "대부",
            "국가대표", "토이스토리3", "마당을 나온 암탉", "죽은 시인의 사회", "서유쌍기",
            "킹콩", "반지의 제왕 : 왕의 귀환", "8월의 크리스마스", "미녀는 괴로워", "나 홀로 집에",
            "파이란", "더 록", "로마의 휴일", "매트릭스", "가위손",
            "양들의 침묵", "A.I.", "집으로", "글래디에이터", "쇼생크 탈출",
            "인생은 아름다워", "피아니스트", "사운드 오브 뮤직", "ET", "나비효과",
            "쥬라기 공원", "바람과 함께 사라지다", "아마데우스", "라스트 모히칸", "센과 치히로의 행방불명",
            "에일리언", "터미네이터2 : 심판의 날", "테이큰", "브레이브 하트", "CINEMA PAEADISO",
            "월.E", "써니", "완득이", "괴물", "라디오스타",
            "비열한 거리", "왕의 남자", "아일랜드", "웰컴 투 동막골", "헬보이 : 골든아미",
            "백 투 더 퓨쳐", "여인의 향기", "Groundhog Day", "혹성탈출 : 진화의 시작",
            "아름다운 비행", "내 이름은 칸", "해리포터 : 죽음의 성물2", "마더", "킹콩을 들다",
            "쿵푸팬더2", "짱구는 못말려 : 초시공! 태풍을 부르는 나의 신부", "아저씨"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("스피너 테스트");

        Spinner spinner = (Spinner) findViewById(R.id.spinner1);

        ArrayAdapter<String> adapter;
        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, movieName);
        spinner.setAdapter(adapter);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                ImageView ivPoster = (ImageView)findViewById(R.id.ivPoster);
                final int pos = position;
                ivPoster.setImageResource(posterID[pos]);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                Toast.makeText(getApplicationContext(),"영화 제목을 선택해주세요.", Toast.LENGTH_SHORT).show();
            }
        });
    }
}